<footer id="footer-top-placeholder" style="background-color: #EFE7DA; line-height: 1.4;">
    <div class="clearfix center px3 pb3" style="max-width: 1440px;">
        <div class="left-align col col-12 sm-col-12 md-col-4">
            <img style="max-width: 100%;" src="<?php echo env('WP_HOME'); ?>/include/img/MH_Greyscale.png" />
            <p style="max-width:15em;">
                Musik Hallandia är en musikinstitution, helägd av Region Halland.
            </p>
            <p>
                <a class="rh-link--navigation" href="">Facebook</a>
            </p>
            <p>
                <a class="rh-link--navigation" href="">Instagram</a>
            </p>
            <p>
                <a class="rh-link--navigation" href="">E-post</a>
            </p>

        </div>

        <div class="left-align col col-12 sm-col-4 md-col-2">
            <p class="h2 pt3">Sidor</p>
            <?php ($first_level_pages = get_region_halland_tree_first_level()); ?>
            <?php if(isset($first_level_pages) && !empty($first_level_pages)): ?>
                <ul>
                    <?php $__currentLoopData = $first_level_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $first_level_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($first_level_page->active === true): ?>
                            <li>
                                <a class="active rh-link--navigation" href="<?php echo e($first_level_page->url); ?>"><?php echo e($first_level_page->post_title); ?></a>
                            </li>
                        <?php else: ?>
                            <li>
                                <a class="rh-link--navigation" href="<?php echo e($first_level_page->url); ?>"><?php echo e($first_level_page->post_title); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
        <div class="left-align col col-12 sm-col-4 md-col-3">
            <p class="h2 pt3">Om oss</p>
            <ul>
                <li><a class="rh-link--navigation" href="/om-oss">Om oss</a></li>
                <li><a class="rh-link--navigation" href="/">Vår vision</a></li>
                <li><a class="rh-link--navigation" href="/">Vårt uppdrag</a></li>
                <li><a class="rh-link--navigation" href="/">Lediga jobb</a></li>
                <li><a class="rh-link--navigation" href="/">Kontakt</a></li>
                <li><a class="rh-link--navigation" href="/">Press & Media</a></li>
            </ul>
        </div>

        <div class="left-align col col-12 sm-col-4 md-col-3">
            <p class="h2 pt3">
                Kontakt
            </p>
            <p>
                <strong>Besöksadress:</strong><br>
                Kultur i Halland<br>
                Kronobränneriet<br>
                Skonertgatan 12A, Halmstad
            </p>
            <p>
                <strong>Postadress:</strong><br>
                Region Halland<br>
                Kultur i Halland<br>
                Box 517, 301 80 Halmstad<br>
            </p>
            <p>
                <strong>Telefon:</strong> 035 - 13 48 00<br>
                <strong>Fax:</strong> 035 - 13 54 44
            </p>
            <p>
                <a class="rh-link--navigation" href="">Kontakta personalen</a>
            </p>

        </div>
    </div>
</footer>



<script src="<?php echo env('WP_HOME'); ?>/include/scripts/jquery.3.3.1.min.js?ver=3.3.1"></script>
<script>
    // **************************************
    // *** Javascript set cookie function ***
    // **************************************
    function setCookie(name,value,days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days*24*60*60*1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "")  + expires + "; path=/";
    }


    // ****************************
    // *** Cookie notice accept ***
    // ****************************
    $("#cookie-consent").on( "click", function() {
        // set cookie with vanilla javascript function
        setCookie('cookie_notice_accepted','1',365);
        // Hide div with cookie notice text + button
        $(".rh-cookie").hide();
    });
</script>


