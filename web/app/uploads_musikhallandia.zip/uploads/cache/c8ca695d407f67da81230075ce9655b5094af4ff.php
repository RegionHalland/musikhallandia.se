<!doctype html>
<html data-server="<?php echo env('SITE_SERVER'); ?>" data-version="1.0.0" style="height: 101%;" <?php (language_attributes()); ?>>
    <?php echo $__env->make('partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <body style="height: 101%" <?php (body_class()); ?>>
        <?php echo $__env->make('partials.jump-to-content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.part-of-region-halland', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.cookie-notice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.nav-site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>