<?php if(function_exists('get_region_halland_find_on_page')): ?>
	<?php ($myNavs = get_region_halland_find_on_page()); ?>
	<?php if(isset($myNavs) && count($myNavs) > 0): ?>
		<?php ($id = uniqid()); ?>
		<div id="content-nav-placeholder"></div>
		<nav class="content-nav-container rh-get-sticky hidden-sm" id="content-nav-container">
			<div>
				<p class="h2" id="<?php echo e($id); ?>">Hitta på sidan</p>
				<ul>
					<?php $__currentLoopData = $myNavs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myNav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="content-nav__item <?php echo e($myNav['class']); ?>" >
							<a class="content-nav__item-link" href="#<?php echo e($myNav['slug']); ?>" data-pointstoid="<?php echo e($myNav['slug']); ?>">
								<?php echo $myNav['content']; ?>

							</a>
							<meta itemprop="position" content="<?php echo e($loop->iteration); ?>" />
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<div id="content-nav-bottom-placeholder"></div>
		</nav>
	<?php endif; ?>
<?php endif; ?>