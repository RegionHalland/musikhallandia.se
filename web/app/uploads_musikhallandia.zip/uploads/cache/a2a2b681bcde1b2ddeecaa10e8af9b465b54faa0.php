<div style="background: #EFE7DA;">
    <nav aria-label="Sidhuvud" class="flex items-center justify-between mx-auto" style="max-width: 1440px; background: #EFE7DA;">
        <a href="<?php echo env('WP_HOME'); ?>"><img style="" src="<?php echo env('WP_HOME'); ?>/include/img/MH_Greyscale.png" /></a>
        <ul class="" style="display: inline;">
            <?php ($first_level_pages = get_region_halland_tree_first_level()); ?>
            <?php $__currentLoopData = $first_level_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="mx1" style="display:inline;">
                <?php if($page->active === true): ?>
                    <a class="rh-link--navigation" href="<?php echo e($page->url); ?>" style="white-space: nowrap; border-bottom:2px solid pink;"><?php echo e($page->post_title); ?></a>
                <?php else: ?>
                    <a class="rh-link--navigation" href="<?php echo e($page->url); ?>" style="white-space: nowrap"><?php echo e($page->post_title); ?></a>
                <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>
</div>