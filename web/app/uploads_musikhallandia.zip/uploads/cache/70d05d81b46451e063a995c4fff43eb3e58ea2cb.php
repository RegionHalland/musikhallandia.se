<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.hero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div style="background: #EFE7DA;">
        <div class="mx-auto" style="max-width: 1440px;">
            <?php if(function_exists('get_region_halland_page_children')): ?>
                <ul class="py2">
                <?php ($myPages = get_region_halland_page_children()); ?>
                <?php if(isset($myPages)): ?>
                    <?php $__currentLoopData = $myPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myChilds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mx1" style="display:inline;">
                            <a class="rh-link--navigation" href="<?php echo e($myChilds->url); ?>"><?php echo e($myChilds->post_title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    
    <?php while(have_posts()): ?> <?php (the_post()); ?>
    <div style="background: #FBF9F4;">
        <div class="center px4 pt2 pb3 rh-article clearfix" style="max-width: 1440px;">
            <main class="col col-12 md-col-8">
                <h1><?php echo e(the_title()); ?></h1>
                <p><strong><?php echo e(get_region_halland_acf_page_ingress()); ?></strong></p>
                <p><?php echo the_content(); ?></p>
                <h2>Vi samarbetar med</h2>
                <div class="p3" style="background: #EDEDED;">
                    Loggor
                </div>
            </main>
        </div>
    </div>

    <?php endwhile; ?>

    <?php echo $__env->make('partials.newsletter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>