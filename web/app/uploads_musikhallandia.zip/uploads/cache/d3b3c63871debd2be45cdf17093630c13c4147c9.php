
<?php if(!is_front_page()): ?>
	<?php ($breadcrumbs = get_region_halland_breadcrumbs_pages()); ?>
	<?php if(isset($breadcrumbs)): ?>

			<ul class="rh-breadcrumbs pl3 mx-auto" style="max-width:1440px;">
				<?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="rh-breadcrumbs__item" itemscope itemprop="itemListElement" itemtype="http://schema.org/ListItem">
						<?php if($breadcrumb['url']): ?>
							<a class="rh-breadcrumbs__link rh-breadcrumbs__link--vuxhalland" href="<?php echo e($breadcrumb['url']); ?>"><?php echo $breadcrumb['name']; ?></a>
						<?php else: ?>
							<a class="rh-breadcrumbs__link rh-breadcrumbs__link--vuxhalland" href="" <?php if($loop->last): ?> aria-current="page" <?php endif; ?>><?php echo $breadcrumb['name']; ?></a>
						<?php endif; ?>
						<meta itemprop="position" content="<?php echo e($loop->iteration); ?>">
					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>

	<?php endif; ?>
<?php endif; ?>