<div style="background:#D3D3D2;line-height:1.4;">
    <div     class="px3 pt3 pb4 clearfix center" style="text-align: center; max-width:1440px;">

        <h1 class="h2">Nyhetsbrev</h1>

        <p class="center" style="max-width: 30em;">Häng med i vad som händer, när det händer.<br>
        Prenumerera på vårt nyhetsbrev och få det senaste om kommande konserter, festivaler och andra evenemang direkt till din mejl.
            </p>
        <a href="" class="rh-link--navigation"><strong>Anmäl dig till vårt nyhetsbrev</strong></a><span class="ml1 icon-arrow-right" style="font-family: feather !important;"></span>

        

    </div>
</div>