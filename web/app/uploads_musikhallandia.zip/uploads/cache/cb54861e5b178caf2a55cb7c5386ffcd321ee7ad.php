<?php echo $__env->make('partials.nav-site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


