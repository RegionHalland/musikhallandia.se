


<?php if(function_exists('get_region_halland_tree_first_second_level_child_pages')): ?>
    <?php ($myPages = get_region_halland_tree_first_second_level_child_pages()); ?>
    <?php if(isset($myPages) && !empty($myPages['first_page'])): ?>
        <div class="py2" style="background: #EFE7DA;">
            <nav aria-label="Navigering nivå två" class="flex items-center justify-between mx-auto" style="max-width: 1440px; background: #EFE7DA;">
                <ul class="" style="display: inline;">
                    <?php if($myPages['first_page']->active == 1): ?>
                        <li class="mx1" style="display:inline;">
                            <a class="rh-link--navigation" href="<?php echo e($myPages['first_page']->url); ?>"><strong><?php echo e($myPages['first_page']->post_title); ?></strong></a>
                        </li>
                    <?php else: ?>
                        <li class="mx1" style="display:inline;">
                            <a class="rh-link--navigation" href="<?php echo e($myPages['first_page']->url); ?>"><?php echo e($myPages['first_page']->post_title); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if(!empty($myPages['page_children'])): ?>
                        <?php $__currentLoopData = $myPages['page_children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myChilds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mx1" style="display:inline;">
                                <?php if($myChilds->active == 1): ?>
                                    <a class="rh-link--navigation" href="<?php echo e($myChilds->url); ?>"><strong><?php echo e($myChilds->post_title); ?></strong></a>
                                <?php else: ?>
                                    <a class="rh-link--navigation" href="<?php echo e($myChilds->url); ?>"><?php echo e($myChilds->post_title); ?></a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
<?php endif; ?>