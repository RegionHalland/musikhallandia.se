Partial laddar
<?php if(function_exists('get_region_halland_nav_sidebar')): ?>
	Funktionen finns
	<?php ($mySidebars = get_region_halland_nav_sidebar()); ?>
	Hämtat nav sidebars
	<?php echo e(var_dump()); ?>

	<?php if(isset($mySidebars) && !empty($mySidebars['page_children'])): ?>
		CHILDREN EXISTS
	<div>
		<nav class="sidebar-nav">
			<ul class="sidebar-nav__list">
				<li class="sidebar-nav__item active">
					<span class="sidebar-nav__label"><?php echo e($mySidebars['current_page']->post_title); ?></span>
					<?php if(!empty($mySidebars['page_children'])): ?>
						<ul class="sidebar-nav__sublist" aria-label="Navigation till undersidor">
							<?php $__currentLoopData = $mySidebars['page_children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="sidebar-nav__item">
									<a class="sidebar-nav__link" href="<?php echo e($myChild->url); ?>"><?php echo e($myChild->post_title); ?></a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					<?php endif; ?>
				</li>
			</ul>
		</nav>
	</div>
	<?php endif; ?>
<?php endif; ?>
