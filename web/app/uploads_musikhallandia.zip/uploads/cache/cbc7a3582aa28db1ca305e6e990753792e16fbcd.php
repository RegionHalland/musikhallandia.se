<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.hero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="rh-xpad-A pt3 pb3" style="background: #FBF9F4">
        <div class="rh-xpad-B mx-auto" style="max-width: 1440px;">
            <main>
                <div class="clearfix">
                    <div class="col col-12 md-col-9 rh-article">
                        <?php while(have_posts()): ?> <?php (the_post()); ?>
                            <h1><?php echo e($post->post_title); ?></h1>

                            <strong>
                                <?php echo e(get_region_halland_acf_page_evenemang_ingress()); ?>

                            </strong>

                            <p>
                                <?php echo e(the_content()); ?>

                            </p>
                            <?php ($myBiljett = get_region_halland_acf_page_evenemang_biljett()); ?>
                            <?php if($myBiljett['biljett_has_link'] == 1): ?>
                                <a href="<?php echo e($myBiljett['biljett_url']); ?>" class="rh-round-button" style="height: 3em; padding-left:1em; padding-right: 1em; border-radius: 3em;">Köp biljett</a>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    </div>
                    <div class="rh-xpad--left col col-12 md-col-3" >
                        <div class="p2 " style="background: #EFE7DA;">
                            <div class="pb3 mt2" style="border-bottom: 1px solid black;">
                                <h2>Information</h2><br>
                                <p>
                                    <strong>Var:</strong> <?php echo e(get_region_halland_acf_page_evenemang_spelstalle()); ?>, <?php echo e(get_region_halland_acf_page_evenemang_stad()); ?>

                                </p>
                                <p>
                                    <strong>När:</strong> <?php echo e(get_region_halland_acf_page_evenemang_speltid()); ?>

                                </p>
                                <p>
                                    <strong>Länkar:</strong>

                                <?php ($myInformation = get_region_halland_acf_page_evenemang_information()); ?>
                                <?php $__currentLoopData = $myInformation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($information['has_link']): ?>
                                        <a href="<?php echo e($information['link_url']); ?>" target="<?php echo e($information['link_target']); ?>"><?php echo e($information['link_title']); ?></a><br>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                            </div>
                            <div class="pb3 mt3 mb3" style="border-bottom: 1px solid black;">
                                <h2>Arrangörer</h2>
                                <p>
                                <?php ($myArrangor = get_region_halland_acf_page_evenemang_arrangor()); ?>
                                <?php $__currentLoopData = $myArrangor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrangor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($arrangor['has_link']): ?>
                                        <a href="<?php echo e($arrangor['link_url']); ?>" target="<?php echo e($arrangor['link_target']); ?>"><?php echo e($arrangor['link_title']); ?></a><br>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>



        </div>

    </div>
    <?php echo $__env->make('partials.newsletter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>