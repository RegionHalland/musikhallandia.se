

<?php if(function_exists('get_region_halland_tree_first_second_level_child_pages')): ?>
    <?php ($myPages = get_region_halland_tree_first_second_level_child_pages()); ?>
    <?php if(isset($myPages) && !empty($myPages['first_page'])): ?>
        <?php if($myPages['first_page']->active == 1): ?>
            <a href="<?php echo e($myPages['first_page']->url); ?>"><strong><?php echo e($myPages['first_page']->post_title); ?></strong></a>
        <?php else: ?>
            <a href="<?php echo e($myPages['first_page']->url); ?>"><?php echo e($myPages['first_page']->post_title); ?></a>
        <?php endif; ?>
        <?php if(!empty($myPages['page_children'])): ?>
            <?php $__currentLoopData = $myPages['page_children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myChilds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($myChilds->active == 1): ?>
                    <a href="<?php echo e($myChilds->url); ?>"><strong><?php echo e($myChilds->post_title); ?></strong></a>
                <?php else: ?>
                    <a href="<?php echo e($myChilds->url); ?>"><?php echo e($myChilds->post_title); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>