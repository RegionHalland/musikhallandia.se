<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('partials.hero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('partials.nav-level2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<main>
		<div class="rh-xpad-A pt3 pb3" style="background: #FBF9F4">
			<div class="rh-xpad-B mx-auto" style="max-width: 1440px;">
				<div class="clearfix">
					
					<div class="col col-12 md-col-9 rh-article">
						<?php while(have_posts()): ?> <?php (the_post()); ?>
						<h1><?php echo e($post->post_title); ?></h1>

						<strong>
							<?php echo e(get_region_halland_acf_page_ingress()); ?>

						</strong>

						<p>
							<?php echo e(the_content()); ?>

						</p>
						<?php endwhile; ?>
					</div>
				</div>
			</div>
		</div>

		
		<div class="rh-xpad-A pt3 pb3" style="background: #EFE7DA;">
			<div class="rh-xpad-B mx-auto" style="max-width: 1440px;">
				<?php ($myBlurbs = get_region_halland_acf_main_post_page_links_blurbs()); ?>
				<?php if(isset($myBlurbs)): ?>
					<ul>
						<?php $__currentLoopData = $myBlurbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blurbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="pb4">
								<div class="clearfix">
									<div class="mr3" style="float:left;">
										<?php echo $blurbs['image']; ?>

									</div>
									<h2><?php echo e($blurbs['post_title']); ?></h2>
									<?php echo e($blurbs['post_content']); ?>

								</div>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				<?php endif; ?>
			</div>
		</div>
	</main>
	<?php echo $__env->make('partials.newsletter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>