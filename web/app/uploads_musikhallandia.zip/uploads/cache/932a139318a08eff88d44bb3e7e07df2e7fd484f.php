<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.hero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.nav-level2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <div class="rh-xpad-A pt3 pb3" style="background: #FBF9F4">
            <div class="rh-xpad-B mx-auto" style="max-width: 1440px;">
                <div class="clearfix">
                    
                    <div class="col col-12 md-col-9 rh-article">
                        <?php while(have_posts()): ?> <?php (the_post()); ?>
                            <h1><?php echo e($post->post_title); ?></h1>

                            <strong>
                                <?php echo e(get_region_halland_acf_page_ingress()); ?>

                            </strong>

                            <p>
                                <?php echo e(the_content()); ?>

                            </p>



                        <?php endwhile; ?>
                    </div>

                    
                    <?php ($myData = get_region_halland_acf_main_post_page_contact_cards()); ?>
                    <?php if(isset($myData)): ?>
                        <div class="col col-12">
                            <ul>
                            <?php $__currentLoopData = $myData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="col col-12 sm-col-12 md-col-6 lg-col-4 pb4">
                                    <div class="clearfix">
                                        <?php if($data['contact_has_image']): ?>
                                            <div class="mr3" style="text-align:center; overflow: hidden; position: relative;">
                                                <img src="<?php echo e($data['contact_image_url']); ?>">
                                                
                                                <span style="width:0; height: 0; position: absolute; bottom: 0; left: 0; border-left: 30px solid #FA3CB4; border-top: 80px solid transparent;"></span>
                                                <span style="width:0; height: 0; position: absolute; top: 0; right: 0; border-right: 30px solid #FA3CB4; border-bottom: 80px solid transparent;"></span>
                                            </div>
                                        <?php endif; ?>
                                        <h2><?php echo $data['contact_name']; ?></h2>
                                            <?php echo $data['post_content']; ?>

                                        <p><?php echo e($data['contact_epost']); ?></p>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    
                    

                </div>
            </div>
        </div>
    </main>
    <?php echo $__env->make('partials.newsletter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>